/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 373.0, "minX": 0.0, "maxY": 204865.0, "series": [{"data": [[0.0, 373.0], [0.1, 373.0], [0.2, 712.0], [0.3, 712.0], [0.4, 728.0], [0.5, 728.0], [0.6, 728.0], [0.7, 730.0], [0.8, 812.0], [0.9, 812.0], [1.0, 900.0], [1.1, 900.0], [1.2, 939.0], [1.3, 939.0], [1.4, 988.0], [1.5, 988.0], [1.6, 998.0], [1.7, 998.0], [1.8, 1023.0], [1.9, 1023.0], [2.0, 1157.0], [2.1, 1157.0], [2.2, 1293.0], [2.3, 1293.0], [2.4, 1307.0], [2.5, 1307.0], [2.6, 1587.0], [2.7, 1587.0], [2.8, 1587.0], [2.9, 1644.0], [3.0, 1644.0], [3.1, 1931.0], [3.2, 1931.0], [3.3, 1939.0], [3.4, 1939.0], [3.5, 2082.0], [3.6, 2082.0], [3.7, 2084.0], [3.8, 2084.0], [3.9, 2140.0], [4.0, 2140.0], [4.1, 2258.0], [4.2, 2258.0], [4.3, 2348.0], [4.4, 2348.0], [4.5, 2381.0], [4.6, 2381.0], [4.7, 2396.0], [4.8, 2396.0], [4.9, 2406.0], [5.0, 2406.0], [5.1, 2410.0], [5.2, 2410.0], [5.3, 2457.0], [5.4, 2457.0], [5.5, 2480.0], [5.6, 2480.0], [5.7, 2546.0], [5.8, 2546.0], [5.9, 2560.0], [6.0, 2560.0], [6.1, 2641.0], [6.2, 2641.0], [6.3, 2653.0], [6.4, 2653.0], [6.5, 2689.0], [6.6, 2689.0], [6.7, 2701.0], [6.8, 2701.0], [6.9, 2740.0], [7.0, 2740.0], [7.1, 2840.0], [7.2, 2840.0], [7.3, 2913.0], [7.4, 2913.0], [7.5, 2994.0], [7.6, 2994.0], [7.7, 2999.0], [7.8, 2999.0], [7.9, 3163.0], [8.0, 3163.0], [8.1, 3164.0], [8.2, 3164.0], [8.3, 3219.0], [8.4, 3219.0], [8.5, 3238.0], [8.6, 3238.0], [8.7, 3257.0], [8.8, 3263.0], [8.9, 3263.0], [9.0, 3268.0], [9.1, 3268.0], [9.2, 3312.0], [9.3, 3312.0], [9.4, 3351.0], [9.5, 3351.0], [9.6, 3425.0], [9.7, 3425.0], [9.8, 3430.0], [9.9, 3430.0], [10.0, 3451.0], [10.1, 3451.0], [10.2, 3461.0], [10.3, 3461.0], [10.4, 3472.0], [10.5, 3472.0], [10.6, 3595.0], [10.7, 3595.0], [10.8, 3608.0], [10.9, 3608.0], [11.0, 3613.0], [11.1, 3613.0], [11.2, 3672.0], [11.3, 3672.0], [11.4, 3761.0], [11.5, 3761.0], [11.6, 3796.0], [11.7, 3796.0], [11.8, 3976.0], [11.9, 3976.0], [12.0, 4026.0], [12.1, 4026.0], [12.2, 4111.0], [12.3, 4111.0], [12.4, 4168.0], [12.5, 4168.0], [12.6, 4388.0], [12.7, 4388.0], [12.8, 4441.0], [12.9, 4441.0], [13.0, 4518.0], [13.1, 4518.0], [13.2, 4646.0], [13.3, 4646.0], [13.4, 4710.0], [13.5, 4710.0], [13.6, 4754.0], [13.7, 4754.0], [13.8, 4804.0], [13.9, 4804.0], [14.0, 4860.0], [14.1, 4860.0], [14.2, 4869.0], [14.3, 4869.0], [14.4, 4906.0], [14.5, 4906.0], [14.6, 4930.0], [14.7, 4930.0], [14.8, 4945.0], [14.9, 4945.0], [15.0, 5188.0], [15.1, 5188.0], [15.2, 5241.0], [15.3, 5241.0], [15.4, 5275.0], [15.5, 5275.0], [15.6, 5305.0], [15.7, 5305.0], [15.8, 5320.0], [15.9, 5320.0], [16.0, 5323.0], [16.1, 5323.0], [16.2, 5353.0], [16.3, 5353.0], [16.4, 5381.0], [16.5, 5381.0], [16.6, 5396.0], [16.7, 5396.0], [16.8, 5513.0], [16.9, 5513.0], [17.0, 5515.0], [17.1, 5515.0], [17.2, 5548.0], [17.3, 5548.0], [17.4, 5645.0], [17.5, 5645.0], [17.6, 5651.0], [17.7, 5651.0], [17.8, 5689.0], [17.9, 5689.0], [18.0, 5730.0], [18.1, 5730.0], [18.2, 5743.0], [18.3, 5743.0], [18.4, 5799.0], [18.5, 5799.0], [18.6, 5801.0], [18.7, 5801.0], [18.8, 5897.0], [18.9, 5897.0], [19.0, 5920.0], [19.1, 5920.0], [19.2, 5938.0], [19.3, 5938.0], [19.4, 5940.0], [19.5, 5940.0], [19.6, 5979.0], [19.7, 5979.0], [19.8, 5984.0], [19.9, 5984.0], [20.0, 6026.0], [20.1, 6026.0], [20.2, 6050.0], [20.3, 6050.0], [20.4, 6058.0], [20.5, 6058.0], [20.6, 6066.0], [20.7, 6066.0], [20.8, 6066.0], [20.9, 6066.0], [21.0, 6088.0], [21.1, 6088.0], [21.2, 6091.0], [21.3, 6091.0], [21.4, 6097.0], [21.5, 6097.0], [21.6, 6101.0], [21.7, 6101.0], [21.8, 6129.0], [21.9, 6129.0], [22.0, 6134.0], [22.1, 6134.0], [22.2, 6151.0], [22.3, 6151.0], [22.4, 6153.0], [22.5, 6153.0], [22.6, 6157.0], [22.7, 6157.0], [22.8, 6157.0], [22.9, 6157.0], [23.0, 6192.0], [23.1, 6192.0], [23.2, 6264.0], [23.3, 6264.0], [23.4, 6271.0], [23.5, 6271.0], [23.6, 6282.0], [23.7, 6282.0], [23.8, 6286.0], [23.9, 6286.0], [24.0, 6401.0], [24.1, 6401.0], [24.2, 6408.0], [24.3, 6408.0], [24.4, 6410.0], [24.5, 6410.0], [24.6, 6431.0], [24.7, 6431.0], [24.8, 6435.0], [24.9, 6435.0], [25.0, 6454.0], [25.1, 6454.0], [25.2, 6495.0], [25.3, 6495.0], [25.4, 6496.0], [25.5, 6496.0], [25.6, 6505.0], [25.7, 6505.0], [25.8, 6561.0], [25.9, 6561.0], [26.0, 6580.0], [26.1, 6580.0], [26.2, 6585.0], [26.3, 6585.0], [26.4, 6587.0], [26.5, 6587.0], [26.6, 6601.0], [26.7, 6601.0], [26.8, 6602.0], [26.9, 6602.0], [27.0, 6605.0], [27.1, 6605.0], [27.2, 6615.0], [27.3, 6615.0], [27.4, 6620.0], [27.5, 6620.0], [27.6, 6643.0], [27.7, 6643.0], [27.8, 6656.0], [27.9, 6656.0], [28.0, 6682.0], [28.1, 6682.0], [28.2, 6689.0], [28.3, 6689.0], [28.4, 6693.0], [28.5, 6693.0], [28.6, 6695.0], [28.7, 6695.0], [28.8, 6702.0], [28.9, 6702.0], [29.0, 6726.0], [29.1, 6726.0], [29.2, 6735.0], [29.3, 6735.0], [29.4, 6787.0], [29.5, 6787.0], [29.6, 6788.0], [29.7, 6788.0], [29.8, 6814.0], [29.9, 6814.0], [30.0, 6817.0], [30.1, 6817.0], [30.2, 6866.0], [30.3, 6866.0], [30.4, 6868.0], [30.5, 6868.0], [30.6, 6912.0], [30.7, 6912.0], [30.8, 6929.0], [30.9, 6929.0], [31.0, 6935.0], [31.1, 6935.0], [31.2, 6944.0], [31.3, 6944.0], [31.4, 6984.0], [31.5, 6984.0], [31.6, 7006.0], [31.7, 7006.0], [31.8, 7025.0], [31.9, 7025.0], [32.0, 7036.0], [32.1, 7036.0], [32.2, 7039.0], [32.3, 7039.0], [32.4, 7050.0], [32.5, 7050.0], [32.6, 7084.0], [32.7, 7084.0], [32.8, 7100.0], [32.9, 7100.0], [33.0, 7152.0], [33.1, 7152.0], [33.2, 7180.0], [33.3, 7180.0], [33.4, 7194.0], [33.5, 7194.0], [33.6, 7245.0], [33.7, 7245.0], [33.8, 7265.0], [33.9, 7265.0], [34.0, 7276.0], [34.1, 7276.0], [34.2, 7285.0], [34.3, 7285.0], [34.4, 7316.0], [34.5, 7316.0], [34.6, 7330.0], [34.7, 7330.0], [34.8, 7335.0], [34.9, 7335.0], [35.0, 7349.0], [35.1, 7349.0], [35.2, 7351.0], [35.3, 7351.0], [35.4, 7389.0], [35.5, 7389.0], [35.6, 7392.0], [35.7, 7392.0], [35.8, 7410.0], [35.9, 7410.0], [36.0, 7425.0], [36.1, 7425.0], [36.2, 7446.0], [36.3, 7446.0], [36.4, 7449.0], [36.5, 7449.0], [36.6, 7465.0], [36.7, 7465.0], [36.8, 7471.0], [36.9, 7471.0], [37.0, 7519.0], [37.1, 7519.0], [37.2, 7539.0], [37.3, 7539.0], [37.4, 7557.0], [37.5, 7557.0], [37.6, 7561.0], [37.7, 7561.0], [37.8, 7577.0], [37.9, 7577.0], [38.0, 7581.0], [38.1, 7581.0], [38.2, 7614.0], [38.3, 7614.0], [38.4, 7614.0], [38.5, 7629.0], [38.6, 7629.0], [38.7, 7633.0], [38.8, 7633.0], [38.9, 7637.0], [39.0, 7637.0], [39.1, 7645.0], [39.2, 7645.0], [39.3, 7652.0], [39.4, 7652.0], [39.5, 7677.0], [39.6, 7677.0], [39.7, 7711.0], [39.8, 7711.0], [39.9, 7719.0], [40.0, 7719.0], [40.1, 7721.0], [40.2, 7721.0], [40.3, 7734.0], [40.4, 7734.0], [40.5, 7740.0], [40.6, 7740.0], [40.7, 7746.0], [40.8, 7746.0], [40.9, 7760.0], [41.0, 7760.0], [41.1, 7810.0], [41.2, 7810.0], [41.3, 7842.0], [41.4, 7842.0], [41.5, 7847.0], [41.6, 7847.0], [41.7, 7849.0], [41.8, 7849.0], [41.9, 7882.0], [42.0, 7882.0], [42.1, 7890.0], [42.2, 7890.0], [42.3, 7911.0], [42.4, 7911.0], [42.5, 7939.0], [42.6, 7939.0], [42.7, 7961.0], [42.8, 7961.0], [42.9, 7975.0], [43.0, 7975.0], [43.1, 8018.0], [43.2, 8018.0], [43.3, 8051.0], [43.4, 8051.0], [43.5, 8073.0], [43.6, 8073.0], [43.7, 8088.0], [43.8, 8088.0], [43.9, 8088.0], [44.0, 8088.0], [44.1, 8110.0], [44.2, 8110.0], [44.3, 8122.0], [44.4, 8122.0], [44.5, 8136.0], [44.6, 8136.0], [44.7, 8138.0], [44.8, 8138.0], [44.9, 8151.0], [45.0, 8151.0], [45.1, 8160.0], [45.2, 8160.0], [45.3, 8176.0], [45.4, 8176.0], [45.5, 8188.0], [45.6, 8188.0], [45.7, 8226.0], [45.8, 8226.0], [45.9, 8232.0], [46.0, 8232.0], [46.1, 8242.0], [46.2, 8242.0], [46.3, 8251.0], [46.4, 8251.0], [46.5, 8257.0], [46.6, 8257.0], [46.7, 8265.0], [46.8, 8265.0], [46.9, 8277.0], [47.0, 8277.0], [47.1, 8288.0], [47.2, 8288.0], [47.3, 8289.0], [47.4, 8289.0], [47.5, 8293.0], [47.6, 8293.0], [47.7, 8297.0], [47.8, 8297.0], [47.9, 8302.0], [48.0, 8302.0], [48.1, 8306.0], [48.2, 8306.0], [48.3, 8318.0], [48.4, 8318.0], [48.5, 8324.0], [48.6, 8324.0], [48.7, 8332.0], [48.8, 8332.0], [48.9, 8337.0], [49.0, 8337.0], [49.1, 8355.0], [49.2, 8355.0], [49.3, 8374.0], [49.4, 8374.0], [49.5, 8400.0], [49.6, 8400.0], [49.7, 8402.0], [49.8, 8402.0], [49.9, 8405.0], [50.0, 8405.0], [50.1, 8430.0], [50.2, 8430.0], [50.3, 8434.0], [50.4, 8434.0], [50.5, 8435.0], [50.6, 8435.0], [50.7, 8456.0], [50.8, 8456.0], [50.9, 8458.0], [51.0, 8458.0], [51.1, 8465.0], [51.2, 8465.0], [51.3, 8502.0], [51.4, 8502.0], [51.5, 8525.0], [51.6, 8525.0], [51.7, 8529.0], [51.8, 8529.0], [51.9, 8554.0], [52.0, 8554.0], [52.1, 8585.0], [52.2, 8585.0], [52.3, 8593.0], [52.4, 8593.0], [52.5, 8593.0], [52.6, 8593.0], [52.7, 8606.0], [52.8, 8606.0], [52.9, 8646.0], [53.0, 8646.0], [53.1, 8668.0], [53.2, 8668.0], [53.3, 8673.0], [53.4, 8673.0], [53.5, 8695.0], [53.6, 8695.0], [53.7, 8707.0], [53.8, 8707.0], [53.9, 8708.0], [54.0, 8708.0], [54.1, 8715.0], [54.2, 8715.0], [54.3, 8724.0], [54.4, 8724.0], [54.5, 8735.0], [54.6, 8735.0], [54.7, 8760.0], [54.8, 8760.0], [54.9, 8772.0], [55.0, 8772.0], [55.1, 8788.0], [55.2, 8788.0], [55.3, 8789.0], [55.4, 8789.0], [55.5, 8813.0], [55.6, 8813.0], [55.7, 8820.0], [55.8, 8820.0], [55.9, 8828.0], [56.0, 8828.0], [56.1, 8835.0], [56.2, 8835.0], [56.3, 8838.0], [56.4, 8838.0], [56.5, 8838.0], [56.6, 8838.0], [56.7, 8849.0], [56.8, 8849.0], [56.9, 8873.0], [57.0, 8873.0], [57.1, 8884.0], [57.2, 8884.0], [57.3, 8887.0], [57.4, 8887.0], [57.5, 8897.0], [57.6, 8897.0], [57.7, 8899.0], [57.8, 8899.0], [57.9, 8919.0], [58.0, 8919.0], [58.1, 8932.0], [58.2, 8932.0], [58.3, 8945.0], [58.4, 8945.0], [58.5, 8965.0], [58.6, 8965.0], [58.7, 8977.0], [58.8, 8977.0], [58.9, 8977.0], [59.0, 8977.0], [59.1, 8978.0], [59.2, 8978.0], [59.3, 9021.0], [59.4, 9021.0], [59.5, 9038.0], [59.6, 9038.0], [59.7, 9103.0], [59.8, 9103.0], [59.9, 9141.0], [60.0, 9141.0], [60.1, 9157.0], [60.2, 9157.0], [60.3, 9163.0], [60.4, 9163.0], [60.5, 9193.0], [60.6, 9193.0], [60.7, 9202.0], [60.8, 9202.0], [60.9, 9209.0], [61.0, 9209.0], [61.1, 9216.0], [61.2, 9216.0], [61.3, 9225.0], [61.4, 9225.0], [61.5, 9244.0], [61.6, 9244.0], [61.7, 9250.0], [61.8, 9250.0], [61.9, 9251.0], [62.0, 9251.0], [62.1, 9278.0], [62.2, 9278.0], [62.3, 9281.0], [62.4, 9281.0], [62.5, 9314.0], [62.6, 9314.0], [62.7, 9324.0], [62.8, 9324.0], [62.9, 9347.0], [63.0, 9347.0], [63.1, 9387.0], [63.2, 9387.0], [63.3, 9388.0], [63.4, 9388.0], [63.5, 9394.0], [63.6, 9394.0], [63.7, 9399.0], [63.8, 9399.0], [63.9, 9405.0], [64.0, 9405.0], [64.1, 9406.0], [64.2, 9406.0], [64.3, 9408.0], [64.4, 9408.0], [64.5, 9441.0], [64.6, 9441.0], [64.7, 9469.0], [64.8, 9469.0], [64.9, 9469.0], [65.0, 9469.0], [65.1, 9485.0], [65.2, 9485.0], [65.3, 9516.0], [65.4, 9516.0], [65.5, 9525.0], [65.6, 9525.0], [65.7, 9586.0], [65.8, 9586.0], [65.9, 9598.0], [66.0, 9598.0], [66.1, 9654.0], [66.2, 9654.0], [66.3, 9665.0], [66.4, 9665.0], [66.5, 9678.0], [66.6, 9678.0], [66.7, 9731.0], [66.8, 9731.0], [66.9, 9741.0], [67.0, 9741.0], [67.1, 9759.0], [67.2, 9759.0], [67.3, 9763.0], [67.4, 9763.0], [67.5, 9832.0], [67.6, 9832.0], [67.7, 9874.0], [67.8, 9874.0], [67.9, 9874.0], [68.0, 9874.0], [68.1, 9879.0], [68.2, 9879.0], [68.3, 9886.0], [68.4, 9886.0], [68.5, 9910.0], [68.6, 9910.0], [68.7, 9940.0], [68.8, 9940.0], [68.9, 9957.0], [69.0, 9957.0], [69.1, 9961.0], [69.2, 9961.0], [69.3, 10008.0], [69.4, 10008.0], [69.5, 10024.0], [69.6, 10024.0], [69.7, 10036.0], [69.8, 10036.0], [69.9, 10043.0], [70.0, 10043.0], [70.1, 10047.0], [70.2, 10047.0], [70.3, 10058.0], [70.4, 10058.0], [70.5, 10077.0], [70.6, 10077.0], [70.7, 10082.0], [70.8, 10082.0], [70.9, 10099.0], [71.0, 10099.0], [71.1, 10102.0], [71.2, 10102.0], [71.3, 10103.0], [71.4, 10103.0], [71.5, 10167.0], [71.6, 10167.0], [71.7, 10193.0], [71.8, 10193.0], [71.9, 10194.0], [72.0, 10194.0], [72.1, 10204.0], [72.2, 10204.0], [72.3, 10239.0], [72.4, 10239.0], [72.5, 10241.0], [72.6, 10241.0], [72.7, 10259.0], [72.8, 10259.0], [72.9, 10269.0], [73.0, 10269.0], [73.1, 10278.0], [73.2, 10278.0], [73.3, 10280.0], [73.4, 10280.0], [73.5, 10284.0], [73.6, 10284.0], [73.7, 10327.0], [73.8, 10327.0], [73.9, 10331.0], [74.0, 10331.0], [74.1, 10337.0], [74.2, 10337.0], [74.3, 10337.0], [74.4, 10337.0], [74.5, 10342.0], [74.6, 10342.0], [74.7, 10377.0], [74.8, 10377.0], [74.9, 10397.0], [75.0, 10397.0], [75.1, 10397.0], [75.2, 10397.0], [75.3, 10411.0], [75.4, 10411.0], [75.5, 10418.0], [75.6, 10418.0], [75.7, 10484.0], [75.8, 10484.0], [75.9, 10530.0], [76.0, 10530.0], [76.1, 10624.0], [76.2, 10624.0], [76.3, 10632.0], [76.4, 10632.0], [76.5, 10650.0], [76.6, 10650.0], [76.7, 10676.0], [76.8, 10676.0], [76.9, 10679.0], [77.0, 10679.0], [77.1, 10692.0], [77.2, 10692.0], [77.3, 10729.0], [77.4, 10729.0], [77.5, 10779.0], [77.6, 10779.0], [77.7, 10801.0], [77.8, 10801.0], [77.9, 10829.0], [78.0, 10829.0], [78.1, 10835.0], [78.2, 10835.0], [78.3, 10843.0], [78.4, 10843.0], [78.5, 10852.0], [78.6, 10852.0], [78.7, 10890.0], [78.8, 10890.0], [78.9, 10936.0], [79.0, 10936.0], [79.1, 10960.0], [79.2, 10960.0], [79.3, 10981.0], [79.4, 10981.0], [79.5, 10990.0], [79.6, 10990.0], [79.7, 11077.0], [79.8, 11077.0], [79.9, 11087.0], [80.0, 11087.0], [80.1, 11113.0], [80.2, 11113.0], [80.3, 11115.0], [80.4, 11115.0], [80.5, 11123.0], [80.6, 11123.0], [80.7, 11125.0], [80.8, 11125.0], [80.9, 11132.0], [81.0, 11132.0], [81.1, 11180.0], [81.2, 11180.0], [81.3, 11272.0], [81.4, 11272.0], [81.5, 11307.0], [81.6, 11307.0], [81.7, 11332.0], [81.8, 11332.0], [81.9, 11341.0], [82.0, 11341.0], [82.1, 11365.0], [82.2, 11365.0], [82.3, 11489.0], [82.4, 11489.0], [82.5, 11565.0], [82.6, 11565.0], [82.7, 11655.0], [82.8, 11655.0], [82.9, 11842.0], [83.0, 11842.0], [83.1, 11888.0], [83.2, 11888.0], [83.3, 11888.0], [83.4, 11888.0], [83.5, 13159.0], [83.6, 13159.0], [83.7, 13329.0], [83.8, 13329.0], [83.9, 13474.0], [84.0, 13474.0], [84.1, 13651.0], [84.2, 13651.0], [84.3, 13900.0], [84.4, 13900.0], [84.5, 13916.0], [84.6, 13916.0], [84.7, 14086.0], [84.8, 14086.0], [84.9, 14123.0], [85.0, 14123.0], [85.1, 14165.0], [85.2, 14165.0], [85.3, 14180.0], [85.4, 14180.0], [85.5, 16299.0], [85.6, 16299.0], [85.7, 16849.0], [85.8, 16849.0], [85.9, 16854.0], [86.0, 16854.0], [86.1, 17178.0], [86.2, 17178.0], [86.3, 17263.0], [86.4, 17263.0], [86.5, 17271.0], [86.6, 17271.0], [86.7, 17672.0], [86.8, 17672.0], [86.9, 17723.0], [87.0, 17723.0], [87.1, 17809.0], [87.2, 17809.0], [87.3, 17827.0], [87.4, 17827.0], [87.5, 18010.0], [87.6, 18010.0], [87.7, 18085.0], [87.8, 18085.0], [87.9, 18581.0], [88.0, 18581.0], [88.1, 18706.0], [88.2, 18706.0], [88.3, 18971.0], [88.4, 18971.0], [88.5, 20137.0], [88.6, 20137.0], [88.7, 23143.0], [88.8, 23143.0], [88.9, 27576.0], [89.0, 27576.0], [89.1, 30798.0], [89.2, 30798.0], [89.3, 34824.0], [89.4, 34824.0], [89.5, 39869.0], [89.6, 39869.0], [89.7, 44210.0], [89.8, 44210.0], [89.9, 50277.0], [90.0, 50277.0], [90.1, 55800.0], [90.2, 55800.0], [90.3, 60387.0], [90.4, 60387.0], [90.5, 62564.0], [90.6, 62564.0], [90.7, 70220.0], [90.8, 70220.0], [90.9, 74174.0], [91.0, 74174.0], [91.1, 77966.0], [91.2, 77966.0], [91.3, 83148.0], [91.4, 83148.0], [91.5, 88773.0], [91.6, 88773.0], [91.7, 94068.0], [91.8, 94068.0], [91.9, 99078.0], [92.0, 99078.0], [92.1, 105059.0], [92.2, 105059.0], [92.3, 108980.0], [92.4, 108980.0], [92.5, 110953.0], [92.6, 110953.0], [92.7, 113798.0], [92.8, 113798.0], [92.9, 115705.0], [93.0, 115705.0], [93.1, 119782.0], [93.2, 119782.0], [93.3, 120604.0], [93.4, 120604.0], [93.5, 122678.0], [93.6, 122678.0], [93.7, 124280.0], [93.8, 124280.0], [93.9, 125803.0], [94.0, 125803.0], [94.1, 127929.0], [94.2, 127929.0], [94.3, 128164.0], [94.4, 128164.0], [94.5, 132082.0], [94.6, 132082.0], [94.7, 133006.0], [94.8, 133006.0], [94.9, 137660.0], [95.0, 137660.0], [95.1, 140628.0], [95.2, 140628.0], [95.3, 147390.0], [95.4, 147390.0], [95.5, 148003.0], [95.6, 148003.0], [95.7, 150737.0], [95.8, 150737.0], [95.9, 154580.0], [96.0, 154580.0], [96.1, 156153.0], [96.2, 156153.0], [96.3, 157621.0], [96.4, 157621.0], [96.5, 158706.0], [96.6, 158706.0], [96.7, 160021.0], [96.8, 160021.0], [96.9, 160490.0], [97.0, 160490.0], [97.1, 163066.0], [97.2, 163066.0], [97.3, 163428.0], [97.4, 163428.0], [97.5, 166221.0], [97.6, 166221.0], [97.7, 166878.0], [97.8, 166878.0], [97.9, 170300.0], [98.0, 170300.0], [98.1, 172351.0], [98.2, 172351.0], [98.3, 174737.0], [98.4, 174737.0], [98.5, 175510.0], [98.6, 175510.0], [98.7, 180286.0], [98.8, 180286.0], [98.9, 184146.0], [99.0, 184146.0], [99.1, 189321.0], [99.2, 189321.0], [99.3, 193006.0], [99.4, 193006.0], [99.5, 197968.0], [99.6, 197968.0], [99.7, 201038.0], [99.8, 201038.0], [99.9, 204865.0], [100.0, 204865.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 300.0, "maxY": 12.0, "series": [{"data": [[137600.0, 1.0], [132000.0, 1.0], [148000.0, 1.0], [157600.0, 1.0], [160000.0, 1.0], [204800.0, 1.0], [147300.0, 1.0], [154500.0, 1.0], [156100.0, 1.0], [184100.0, 1.0], [77900.0, 1.0], [83100.0, 1.0], [88700.0, 1.0], [127900.0, 1.0], [133000.0, 1.0], [163400.0, 1.0], [180200.0, 1.0], [193000.0, 1.0], [201000.0, 1.0], [150700.0, 1.0], [158700.0, 1.0], [172300.0, 1.0], [175500.0, 1.0], [174700.0, 1.0], [197900.0, 1.0], [60300.0, 1.0], [62500.0, 1.0], [70200.0, 1.0], [300.0, 1.0], [99000.0, 1.0], [105000.0, 1.0], [122600.0, 1.0], [120600.0, 1.0], [125800.0, 1.0], [124200.0, 1.0], [160400.0, 1.0], [166800.0, 1.0], [700.0, 3.0], [800.0, 1.0], [900.0, 4.0], [1000.0, 1.0], [1100.0, 1.0], [1200.0, 1.0], [1300.0, 1.0], [1500.0, 1.0], [1600.0, 1.0], [1900.0, 2.0], [2000.0, 2.0], [2100.0, 1.0], [2300.0, 3.0], [2200.0, 1.0], [2400.0, 4.0], [2500.0, 2.0], [2600.0, 3.0], [2800.0, 1.0], [2700.0, 2.0], [2900.0, 3.0], [189300.0, 1.0], [3100.0, 2.0], [3200.0, 5.0], [3300.0, 2.0], [3400.0, 5.0], [3500.0, 1.0], [3700.0, 2.0], [3600.0, 3.0], [3900.0, 1.0], [4000.0, 1.0], [4300.0, 1.0], [4100.0, 2.0], [4400.0, 1.0], [4600.0, 1.0], [4500.0, 1.0], [4800.0, 3.0], [4700.0, 2.0], [74100.0, 1.0], [4900.0, 3.0], [5100.0, 1.0], [5200.0, 2.0], [5300.0, 6.0], [5600.0, 3.0], [5500.0, 3.0], [5800.0, 2.0], [5700.0, 3.0], [6000.0, 8.0], [6100.0, 8.0], [5900.0, 5.0], [6200.0, 4.0], [6400.0, 8.0], [6600.0, 11.0], [6500.0, 5.0], [6900.0, 5.0], [6700.0, 5.0], [6800.0, 4.0], [108900.0, 1.0], [7100.0, 4.0], [7000.0, 6.0], [113700.0, 1.0], [110900.0, 1.0], [7300.0, 7.0], [7200.0, 4.0], [115700.0, 1.0], [7400.0, 6.0], [7600.0, 7.0], [7500.0, 6.0], [119700.0, 1.0], [7900.0, 4.0], [7700.0, 7.0], [7800.0, 6.0], [8000.0, 5.0], [8100.0, 8.0], [128100.0, 1.0], [8500.0, 7.0], [8400.0, 9.0], [8200.0, 11.0], [8700.0, 9.0], [8300.0, 8.0], [8600.0, 5.0], [8800.0, 12.0], [9000.0, 2.0], [9100.0, 5.0], [9200.0, 9.0], [8900.0, 7.0], [140600.0, 1.0], [9500.0, 4.0], [9700.0, 4.0], [9400.0, 7.0], [9300.0, 7.0], [9600.0, 3.0], [10200.0, 8.0], [9800.0, 5.0], [10000.0, 9.0], [10100.0, 5.0], [9900.0, 4.0], [163000.0, 1.0], [10700.0, 2.0], [10600.0, 6.0], [10300.0, 8.0], [10400.0, 3.0], [166200.0, 1.0], [10500.0, 1.0], [11100.0, 6.0], [11200.0, 1.0], [10800.0, 6.0], [11000.0, 2.0], [10900.0, 4.0], [11600.0, 1.0], [11300.0, 4.0], [11400.0, 1.0], [11500.0, 1.0], [11800.0, 3.0], [13300.0, 1.0], [13100.0, 1.0], [13400.0, 1.0], [13600.0, 1.0], [14100.0, 3.0], [13900.0, 2.0], [14000.0, 1.0], [16200.0, 1.0], [16800.0, 2.0], [17200.0, 2.0], [17100.0, 1.0], [18000.0, 2.0], [17800.0, 2.0], [17600.0, 1.0], [17700.0, 1.0], [18900.0, 1.0], [18500.0, 1.0], [18700.0, 1.0], [20100.0, 1.0], [23100.0, 1.0], [27500.0, 1.0], [30700.0, 1.0], [34800.0, 1.0], [39800.0, 1.0], [170300.0, 1.0], [44200.0, 1.0], [50200.0, 1.0], [55800.0, 1.0], [94000.0, 1.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 204800.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 9.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 463.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 9.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 463.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 28.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.958333333333334, "minX": 1.73565222E12, "maxY": 50.0, "series": [{"data": [[1.73565222E12, 42.2], [1.73565252E12, 15.105263157894736], [1.73565234E12, 46.42718446601942], [1.73565246E12, 30.11881188118812], [1.73565228E12, 50.0], [1.73565258E12, 4.958333333333334], [1.7356524E12, 38.78409090909091]], "isOverall": false, "label": "Grupo de Usuários", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73565258E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 815.0, "minX": 1.0, "maxY": 67158.5, "series": [{"data": [[32.0, 6918.25], [33.0, 39578.333333333336], [2.0, 1165.0], [35.0, 7426.25], [34.0, 41895.0], [37.0, 28380.25], [36.0, 29751.933333333334], [38.0, 30669.346153846152], [41.0, 23844.52173913043], [40.0, 32670.299999999996], [42.0, 17869.5], [43.0, 28633.199999999997], [45.0, 21899.0], [44.0, 9616.0], [47.0, 7131.5], [46.0, 10411.0], [48.0, 18107.222222222223], [49.0, 19730.5], [3.0, 939.0], [50.0, 12513.217391304346], [4.0, 2410.0], [5.0, 2756.0], [6.0, 4138.919999999998], [7.0, 17522.0], [8.0, 40971.33333333333], [9.0, 6088.333333333333], [10.0, 65388.0], [11.0, 6177.5], [12.0, 26877.833333333332], [13.0, 67158.5], [14.0, 31363.8], [16.0, 11865.0], [1.0, 815.0], [17.0, 10808.75], [18.0, 65442.0], [19.0, 18716.909090909092], [21.0, 36828.22222222222], [22.0, 8383.2], [23.0, 31015.85714285714], [24.0, 30355.999999999996], [25.0, 8813.0], [27.0, 25222.300000000003], [28.0, 7810.0], [29.0, 22973.3], [30.0, 31392.75]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[35.57400000000002, 21172.807999999997]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 114.25, "minX": 1.73565222E12, "maxY": 6404.75, "series": [{"data": [[1.73565222E12, 212.75], [1.73565252E12, 6099.233333333334], [1.73565234E12, 5653.0], [1.73565246E12, 6404.75], [1.73565228E12, 3872.65], [1.73565258E12, 2147.5333333333333], [1.7356524E12, 4428.25]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.73565222E12, 114.25], [1.73565252E12, 578.8666666666667], [1.73565234E12, 784.5166666666667], [1.73565246E12, 769.2833333333333], [1.73565228E12, 708.35], [1.73565258E12, 182.8], [1.7356524E12, 670.2666666666667]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73565258E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 2190.625000000001, "minX": 1.73565222E12, "maxY": 29933.227722772284, "series": [{"data": [[1.73565222E12, 3872.7999999999997], [1.73565252E12, 24536.000000000004], [1.73565234E12, 19371.077669902912], [1.73565246E12, 29933.227722772284], [1.73565228E12, 11325.999999999998], [1.73565258E12, 2190.625000000001], [1.7356524E12, 28854.613636363643]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73565258E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 2190.625000000001, "minX": 1.73565222E12, "maxY": 29933.13861386138, "series": [{"data": [[1.73565222E12, 3870.5333333333338], [1.73565252E12, 24535.921052631573], [1.73565234E12, 19370.902912621354], [1.73565246E12, 29933.13861386138], [1.73565228E12, 11325.935483870968], [1.73565258E12, 2190.625000000001], [1.7356524E12, 28854.431818181816]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73565258E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 110.04166666666666, "minX": 1.73565222E12, "maxY": 606.9333333333333, "series": [{"data": [[1.73565222E12, 606.9333333333333], [1.73565252E12, 177.92105263157885], [1.73565234E12, 182.35922330097085], [1.73565246E12, 155.3267326732674], [1.73565228E12, 242.72043010752685], [1.73565258E12, 110.04166666666666], [1.7356524E12, 195.1477272727273]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73565258E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 730.0, "minX": 1.73565222E12, "maxY": 204865.0, "series": [{"data": [[1.73565222E12, 8835.0], [1.73565252E12, 174737.0], [1.73565234E12, 122678.0], [1.73565246E12, 204865.0], [1.73565228E12, 62564.0], [1.73565258E12, 3608.0], [1.7356524E12, 180286.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.73565222E12, 2396.0], [1.73565252E12, 1157.0], [1.73565234E12, 5651.0], [1.73565246E12, 5513.0], [1.73565228E12, 2641.0], [1.73565258E12, 730.0], [1.7356524E12, 3163.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.73565222E12, 7700.400000000001], [1.73565252E12, 122442.0], [1.73565234E12, 81075.20000000004], [1.73565246E12, 161262.8], [1.73565228E12, 22541.799999999992], [1.73565258E12, 3523.0], [1.7356524E12, 150737.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.73565222E12, 8835.0], [1.73565252E12, 174737.0], [1.73565234E12, 122678.0], [1.73565246E12, 204865.0], [1.73565228E12, 62564.0], [1.73565258E12, 3608.0], [1.7356524E12, 180286.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.73565222E12, 3263.0], [1.73565252E12, 8460.5], [1.73565234E12, 9874.0], [1.73565246E12, 8595.5], [1.73565228E12, 8430.0], [1.73565258E12, 2303.0], [1.7356524E12, 7847.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.73565222E12, 8835.0], [1.73565252E12, 132313.0], [1.73565234E12, 106235.29999999999], [1.73565246E12, 189873.74999999997], [1.73565228E12, 41605.399999999965], [1.73565258E12, 3604.75], [1.7356524E12, 166221.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73565258E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 863.0, "minX": 1.0, "maxY": 18047.5, "series": [{"data": [[2.0, 1147.5], [8.0, 9122.0], [9.0, 8491.5], [10.0, 9592.0], [11.0, 10702.5], [3.0, 3401.0], [12.0, 13490.0], [14.0, 18047.5], [4.0, 3344.0], [1.0, 1023.0], [5.0, 6587.0], [6.0, 7847.0], [7.0, 8088.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[8.0, 2260.5], [10.0, 3364.5], [5.0, 863.0], [11.0, 4732.0], [12.0, 4072.0], [6.0, 1644.0], [14.0, 5321.5], [7.0, 2560.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 14.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 863.0, "minX": 1.0, "maxY": 18047.5, "series": [{"data": [[2.0, 1147.5], [8.0, 9122.0], [9.0, 8491.0], [10.0, 9592.0], [11.0, 10702.5], [3.0, 3401.0], [12.0, 13489.5], [14.0, 18047.5], [4.0, 3338.5], [1.0, 1023.0], [5.0, 6587.0], [6.0, 7847.0], [7.0, 8088.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[8.0, 2260.5], [10.0, 3364.5], [5.0, 863.0], [11.0, 4732.0], [12.0, 4072.0], [6.0, 1644.0], [14.0, 5321.5], [7.0, 2560.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 14.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.36666666666666664, "minX": 1.73565222E12, "maxY": 1.6333333333333333, "series": [{"data": [[1.73565222E12, 1.0], [1.73565252E12, 1.0166666666666666], [1.73565234E12, 1.5666666666666667], [1.73565246E12, 1.3833333333333333], [1.73565228E12, 1.6333333333333333], [1.73565258E12, 0.36666666666666664], [1.7356524E12, 1.3666666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73565258E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.03333333333333333, "minX": 1.73565222E12, "maxY": 1.6, "series": [{"data": [[1.73565222E12, 0.25], [1.73565252E12, 1.2333333333333334], [1.73565234E12, 1.55], [1.73565246E12, 1.6], [1.73565228E12, 1.5166666666666666], [1.73565258E12, 0.4], [1.7356524E12, 1.3166666666666667]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.73565252E12, 0.03333333333333333], [1.73565234E12, 0.16666666666666666], [1.73565246E12, 0.08333333333333333], [1.73565228E12, 0.03333333333333333], [1.7356524E12, 0.15]], "isOverall": false, "label": "502", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.73565258E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.03333333333333333, "minX": 1.73565222E12, "maxY": 1.6, "series": [{"data": [[1.73565222E12, 0.25], [1.73565252E12, 1.2333333333333334], [1.73565234E12, 1.55], [1.73565246E12, 1.6], [1.73565228E12, 1.5166666666666666], [1.73565258E12, 0.4], [1.7356524E12, 1.3166666666666667]], "isOverall": false, "label": "HTTP Request-success", "isController": false}, {"data": [[1.73565252E12, 0.03333333333333333], [1.73565234E12, 0.16666666666666666], [1.73565246E12, 0.08333333333333333], [1.73565228E12, 0.03333333333333333], [1.7356524E12, 0.15]], "isOverall": false, "label": "HTTP Request-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73565258E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.03333333333333333, "minX": 1.73565222E12, "maxY": 1.6, "series": [{"data": [[1.73565222E12, 0.25], [1.73565252E12, 1.2333333333333334], [1.73565234E12, 1.55], [1.73565246E12, 1.6], [1.73565228E12, 1.5166666666666666], [1.73565258E12, 0.4], [1.7356524E12, 1.3166666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.73565252E12, 0.03333333333333333], [1.73565234E12, 0.16666666666666666], [1.73565246E12, 0.08333333333333333], [1.73565228E12, 0.03333333333333333], [1.7356524E12, 0.15]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.73565258E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, -10800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

